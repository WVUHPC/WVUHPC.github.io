High Performance Analytics
--------------------------------

The command to run the mapper and reducer...

`less msnbc990928.seq | ./mapper.R | sort | ./reducer.R`

1 - Code for the mapper.R is included in the zip file.

2 - Code for the reducer.R is included in the zip file. Decided to use agglomerative clustering and produce dendrograms for each of the clusters as they provided better visualization than other methods.

3 - The cluster plots are named dendrogram#.png where # is the number of the cluster from 1 to 10. They can be created by running the mapper and reducer but they are also included in the zip file.

Each of the ten clusters represent a period of time during an single day of web server logs to the msnbc.com and msn.com web sites. While the clusters fall sequentially one after another in time, they are not equadistant from each other and we don't the specific time that they represent. Just that generally, cluster 1 is in the early hours, cluster 5 and 6 are around mid-day and cluster 10 is late night and so on.

Looking for themes in the clusters, I decided to start with the `frontpage` as that is where most users most likely started on the website. There were certain categories that consistently clustered with `frontpage`. Notably, 'msn-news' in batches 1, 3, 5, 10 and `bbs` in batches 1, 4, 6, 7, and 8. It could be that there were direct links from the frontpage to these sections of the website. `bbs` seems to cluster with `frontpage` more often in the middle of the day. It's likely that there were more people on the website to interact with midday on a bulletin board service.

Going through the categories, I thought it might be interesting to see the relationship between `msn-news` and `news` and `msn-sports` and `sports`. As the topics are the same, you would you think that someone interested in sports might visit both categories but that does not appear to be the case. Only once, in batch 6, were `news` and `msn-news` closely clustered together. While `sports` and `msn-sports` were always quite far, attracting different audiences. I assume that this must be due to the structure of the two websites, msnbc.com and msn.com. They must not have shared much traffic between the two sites, perhaps they didn't link to each other or perhaps it was due to how the server logs between the sites were generated, otherwise we would expect to see these two pairs of similar categories being closely clustered.

Clustering produces quite a bit of information. There were many other relationships of note but those were the two that caught my eye.

