#! /usr/bin/env Rscript

# reducer.R

library(vegan)

trimWhiteSpace <- function(line) gsub("(^ +)|( +$)", "", line)

input <- file("stdin", open = "r")

# create categories vector
categories <- c("frontpage", "news", "tech", "local", "opinion", "on-air", 
                "misc", "weather", "msn-news", "health", "living", "business", 
                "msn-sports", "sports", "summary", "bbs", "travel")

# note: if we should be reading this in from the file instead, here is the code...
# categories <- scan(file("msnbc990928.seq", open = "r"), what = character(), skip = 2, nlines = 1)

while (length(line <- readLines(input, 1, warn = FALSE)) > 0) {  
  line <- trimWhiteSpace(line)
  value <- as.numeric(unlist(strsplit(line, "\t")))
  
  if (!exists("key.current")) {
    # start creating dataframe when none is set
    key.current <- value[1]
    df.current <- data.frame(rbind(value[2:18]))
    colnames(df.current) <- categories
  } else if (key.current == value[1]) {
    # keep adding to dataframe
    df.current <- rbind(df.current, value[2:18])
    
    # after 1000 start analyzing
    if (nrow(df.current) == 1000) {
      # run cluster analysis
      
      # 1. change all counts to 1
      df.current <- as.data.frame(ifelse(df.current > 0, 1, 0))
      
      # 2. compute Jaccard distances among the page categories
      df.dist <- 1 - vegdist(t(df.current), method = "jaccard")
      
      # 3. cluster results
      clust.res <- hclust(df.dist)
      plot(clust.res)
      
      png(filename = paste("dendrogram", key.current, ".png", sep = ""))
      plot(clust.res)
      dev.off()
      #write.table(df.current.2, file = paste("df", key.current, ".csv", sep = ""), sep = ",", row.names = FALSE)
    }
  } else if (key.current != value[1]) {
    # transition on key change
    key.current <- value[1]
    df.current <- data.frame(rbind(value[2:18]))
    colnames(df.current) <- categories
  }
}

close(input)
