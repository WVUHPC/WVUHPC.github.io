#! /usr/bin/env Rscript

# mapper.R

# assigning a key and transforming a line of page visits into a line of counts for each of the 17 categories
transformLine <- function(line, n) {
  key <- ((n - 8) %/% 100000 + 1)
  counts <- paste(tabulate(as.numeric(unlist(strsplit(line, " "))), nbins = 17), sep = "\t")
  cat(key, paste(counts, sep = "\t"), sep = "\t")
}

# start standard input and count the lines
input <- file("stdin", "r")
n <- 0

while (length(line <- readLines(input, 1, warn = FALSE)) > 0) {
  n <- n + 1
  
  # only want the first 1,000 of each 100,000 users
  if (n > 7 & ((n - 8) %% 100000 <= 999) ) {
    result <- transformLine(line, n)
    cat(result, "\n")
  }
}

close(input)
