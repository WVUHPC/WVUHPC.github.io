#! /usr/bin/env Rscript

calls <- read.csv("out.txt", header=FALSE, sep="\t")

attach(calls)
date <- as.factor(date)
length.call <- as.numeric(length.call)

# hist(length.call)

by(calls[,"length.call"], calls[, "date"], mean)
